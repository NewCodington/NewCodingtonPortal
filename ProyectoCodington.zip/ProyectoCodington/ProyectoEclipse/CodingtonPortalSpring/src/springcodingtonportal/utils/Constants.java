package springcodingtonportal.utils;

public class Constants {
	private Integer BUSSINES;
	private Integer MARKET;
	private Integer MUSEUM;
	private Integer PARK;
	private Integer STADIUM;
	private Integer THEATER;
	private Integer TOURISM;
	private Integer ZOO;
	
	
	public Integer getBUSSINES() {
		return BUSSINES;
	}
	public void setBUSSINES(Integer bUSSINES) {
		BUSSINES = bUSSINES;
	}
	public Integer getMARKET() {
		return MARKET;
	}
	public void setMARKET(Integer mARKET) {
		MARKET = mARKET;
	}
	public Integer getMUSEUM() {
		return MUSEUM;
	}
	public void setMUSEUM(Integer mUSEUM) {
		MUSEUM = mUSEUM;
	}
	public Integer getPARK() {
		return PARK;
	}
	public void setPARK(Integer pARK) {
		PARK = pARK;
	}
	public Integer getSTADIUM() {
		return STADIUM;
	}
	public void setSTADIUM(Integer sTADIUM) {
		STADIUM = sTADIUM;
	}
	public Integer getTHEATER() {
		return THEATER;
	}
	public void setTHEATER(Integer tHEATER) {
		THEATER = tHEATER;
	}
	public Integer getTOURISM() {
		return TOURISM;
	}
	public void setTOURISM(Integer tOURISM) {
		TOURISM = tOURISM;
	}
	public Integer getZOO() {
		return ZOO;
	}
	public void setZOO(Integer zOO) {
		ZOO = zOO;
	}
	
	
	
	}
